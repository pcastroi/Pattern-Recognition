clear all; close all;
%
% Exercise 11: Question 2
%

% Result of the xor
r1=xor(0,0);
r2=xor(0,1);
r3=xor(1,0);
r4=xor(1,1);