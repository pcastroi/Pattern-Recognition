clear all; close all; clc;
% 
% Exercise 13: Question 2
%

load('iris_dataset.mat');
nctool();